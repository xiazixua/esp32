/*
 * lwip_napt_override.h
 *
 * Restoration stub for the Hoshino ESP32 Watch Gateway build.
 *
 * The original project shipped this header alongside main.cpp, but it was lost
 * together with sdkconfig.upesy_wroom_lowmem_idf. main.cpp does:
 *
 *     #ifndef HOSHINO_DISABLE_LWIP_OVERRIDE
 *     #include <lwip_napt_override.h>
 *     ...
 *     hoshino_lwip_napt_override_marker();
 *     #endif
 *
 * NAPT forwarding in this firmware is already provided end-to-end by:
 *   - sdkconfig: CONFIG_LWIP_IP_FORWARD=y + CONFIG_LWIP_IPV4_NAPT=y
 *                + CONFIG_LWIP_L2_TO_L3_COPY=y  (recompiled lwIP in the
 *                  espidf+arduino low-memory env so these take effect)
 *   - runtime:  explicit ip_napt_enable(netif, 1) calls on the SoftAP netif
 *               (see setupWatchNetworkProxy / repairDefaultRoute in main.cpp).
 *
 * The marker() function therefore has no required side effect; a no-op inline
 * keeps the original call site intact without altering NAPT behaviour. If a
 * future recovery of the original header reveals it patched lwIP internals,
 * that implementation can simply replace this stub.
 */
#pragma once

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C++" {
#endif

static inline void hoshino_lwip_napt_override_marker(void) {
    /* no-op marker: NAPT is enabled via sdkconfig + ip_napt_enable() */
}

#ifdef __cplusplus
}
#endif
